package com.project.gas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GasApplicationTests {

	@Test
	void contextLoads() {

	}

}